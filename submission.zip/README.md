# CEEDER
a virtual zen space garden

[enter the garden...](https://dsmaugy.github.io/ceeder/)

## about
CPSC478 Project by Darwin Do, Jack Li, Raff DaVila, and Samantha Trimboli

[project writeup](writeup.pdf)