export { default as Asteroid } from './Asteroid.js';
